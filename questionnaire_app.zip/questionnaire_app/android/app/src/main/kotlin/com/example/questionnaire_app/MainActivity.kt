package com.example.questionnaire_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
